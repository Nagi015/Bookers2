# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '5d5773d807248598f677da500e364c63285f3023b31cd9ba498b795c276c839b13b01f2dbd7175ed0c5840d564107f0268c4ecd3e1e71d04c737e933406104cd'
